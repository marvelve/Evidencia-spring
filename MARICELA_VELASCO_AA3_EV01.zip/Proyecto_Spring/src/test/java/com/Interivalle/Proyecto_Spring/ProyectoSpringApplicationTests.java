package com.Interivalle.Proyecto_Spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
