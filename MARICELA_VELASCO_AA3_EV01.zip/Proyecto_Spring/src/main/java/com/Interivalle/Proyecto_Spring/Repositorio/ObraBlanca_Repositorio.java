/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.Interivalle.Proyecto_Spring.Repositorio;

import com.Interivalle.Proyecto_Spring.Modelo.Obra_Blanca;
import org.springframework.data.jpa.repository.JpaRepository;


/**
 *
 * @author Marysela Velasco
 */
public interface ObraBlanca_Repositorio extends JpaRepository<Obra_Blanca, Long>{

    
}
